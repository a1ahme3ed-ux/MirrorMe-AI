import 'package:flutter_test/flutter_test.dart';
import 'package:mirror_me_ai/providers/language_provider.dart';

void main() {
  late LanguageProvider languageProvider;

  setUp(() {
    languageProvider = LanguageProvider();
  });

  test('Default locale is English or Arabic', () {
    expect(languageProvider.locale.languageCode, anyOf('en', 'ar'));
  });

  test('Toggle locale switches language', () async {
    final initial = languageProvider.locale.languageCode;
    await languageProvider.toggleLocale();
    expect(languageProvider.locale.languageCode, isNot(initial));
  });
}
