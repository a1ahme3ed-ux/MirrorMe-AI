import 'package:flutter_test/flutter_test.dart';
import 'package:mirror_me_ai/providers/theme_provider.dart';

void main() {
  late ThemeProvider themeProvider;

  setUp(() {
    themeProvider = ThemeProvider();
  });

  test('Default theme mode is dark or light', () {
    expect(themeProvider.isDarkMode, anyOf(true, false));
  });

  test('Toggle theme switches mode', () async {
    final initial = themeProvider.isDarkMode;
    await themeProvider.toggleTheme();
    expect(themeProvider.isDarkMode, isNot(initial));
  });
}
