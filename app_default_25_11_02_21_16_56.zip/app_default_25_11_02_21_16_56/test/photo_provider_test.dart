import 'package:flutter_test/flutter_test.dart';

import 'package:mirror_me_ai/providers/photo_provider.dart';

void main() {
  late PhotoProvider photoProvider;

  setUp(() {
    photoProvider = PhotoProvider();
  });

  test('Initial photos list is empty', () {
    expect(photoProvider.photos, isEmpty);
  });

  // Further tests require mocking Firebase and ImagePicker.
}
