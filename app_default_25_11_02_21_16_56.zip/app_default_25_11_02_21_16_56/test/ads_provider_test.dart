import 'package:flutter_test/flutter_test.dart';
import 'package:mirror_me_ai/providers/ads_provider.dart';

void main() {
  late AdsProvider adsProvider;

  setUp(() {
    adsProvider = AdsProvider();
  });

  test('Initial banner visibility is false', () {
    expect(adsProvider.isBannerVisible, false);
  });

  test('Show and hide banner change visibility', () {
    adsProvider.showBanner();
    expect(adsProvider.isBannerVisible, true);
    adsProvider.hideBanner();
    expect(adsProvider.isBannerVisible, false);
  });
}
