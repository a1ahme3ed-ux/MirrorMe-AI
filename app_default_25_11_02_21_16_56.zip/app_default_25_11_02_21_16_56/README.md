# MirrorMe AI

## Project Overview
MirrorMe AI is a Flutter-based mobile application that enables users to capture or upload photos and view AI-generated aged versions of themselves (+10 or +20 years). It integrates Firebase services for authentication, storage, and real-time database, along with Unity Ads for monetization. The app supports both English and Arabic languages with proper localization and right-to-left formatting for Arabic.

## Features
- User authentication via Google Sign-In and email/password.
- Upload or capture photos using camera or gallery.
- AI-based aging analysis (+10 / +20 years) with visual results.
- Health and beauty recommendations based on AI analysis.
- Daily progress tracking with photo timeline and comparison.
- AI Chat Health Assistant for food and calorie queries.
- Points system rewarding user engagement and ad interaction.
- Unity Ads banner integration with points reward.
- Dark mode and language toggling (English/Arabic).
- Localization support with Flutter Intl.

## Prerequisites
- Flutter SDK (>= 2.18.0 < 3.0.0)
- Dart SDK included with Flutter
- Android Studio or Xcode (for emulators and device builds)
- Firebase account and project configured
- Unity Ads account with game and ad units

## Installation Steps

1. **Clone the repository**

       git clone https://github.com/yourusername/mirror_me_ai.git
       cd mirror_me_ai

2. **Install dependencies**

       flutter pub get

3. **Configure Firebase**

   - Create a Firebase project at https://console.firebase.google.com/
   - Register your Android and iOS apps.
   - Download `google-services.json` for Android and place it in `android/app/`
   - Download `GoogleService-Info.plist` for iOS and place it in `ios/Runner/`
   - Update `lib/firebase_options.dart` with your Firebase config (use `flutterfire configure` CLI tool).

4. **Setup Unity Ads**

   - Create a Unity Ads project at https://dashboard.unity3d.com/
   - Obtain your Unity Game ID and Ad Unit IDs.
   - Update `.env` file with Unity Ads IDs.
   - For Android, ensure `android/app/src/main/AndroidManifest.xml` contains Unity Ads metadata.
   - For iOS, ensure `ios/Runner/Info.plist` includes Unity Ads Game ID.

5. **Localization**

   - The app supports English and Arabic.
   - Localization files are in `lib/l10n/`.
   - Use `flutter pub run intl_utils:generate` to regenerate localization files if needed.

## Running the Application

- To run on an Android device or emulator:

      flutter run

- To run on an iOS device or simulator:

      flutter run

- To build a release APK:

      flutter build apk --release

- To build an iOS release:

      flutter build ios --release

## Usage Instructions

- On launch, the splash screen displays the app logo and tagline.
- Sign in using Google or email/password.
- On the home screen, upload or capture a photo.
- Select aging increments (+10 or +20 years) to see AI-generated future images.
- View health and beauty recommendations.
- Track daily progress with photo timeline and compare photos side-by-side.
- Use the AI Chat Health Assistant for queries about food and calories.
- Toggle language and dark mode in settings.
- Earn and view points based on usage and ads engagement.
- Unity Ads banner appears at the bottom of the home screen.

## Troubleshooting

- **Firebase initialization errors:** Ensure Firebase is configured correctly with proper files and options.
- **Unity Ads not displaying:** Verify game ID and ad unit IDs are correct and Unity Ads is initialized.
- **Camera or storage permission denied:** Grant permissions manually via device settings or accept permission requests.
- **Localization issues:** Regenerate localization files using intl_utils if translations do not show.
- **Sign-in failures:** Check internet connection and Firebase Authentication setup.

## Project Structure

- `lib/` - Source code
  - `models/` - Data model classes
  - `providers/` - State management providers
  - `screens/` - UI screens
  - `widgets/` - Reusable UI components
  - `services/` - Firebase, AI, and Ads services
  - `utils/` - Constants, themes, localization helpers
  - `l10n/` - Localization files for Arabic and English
  - `main.dart` - App entry point
  - `app.dart` - Root widget and routing
- `assets/` - Static assets like logo and translations
- `android/` - Android project files
- `ios/` - iOS project files
- `test/` - Unit tests

## Contact & Support

- For issues and feature requests, please open an issue on GitHub.
- For commercial support, contact your development team.

Enjoy discovering your future self with MirrorMe AI!
