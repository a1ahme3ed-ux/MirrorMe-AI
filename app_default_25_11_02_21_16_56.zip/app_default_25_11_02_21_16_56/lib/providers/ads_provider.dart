import 'package:flutter/material.dart';
import 'package:flutter_unity_ads/flutter_unity_ads.dart';

import '../utils/constants.dart';

class AdsProvider extends ChangeNotifier {
  bool _isBannerVisible = false;

  bool get isBannerVisible => _isBannerVisible;

  AdsProvider() {
    // Initialization done in main.dart already
  }

  void showBanner() {
    if (!_isBannerVisible) {
      UnityAds.showBanner(
        placementId: Constants.unityBannerAdUnitId,
        listener: UnityBannerAdListener(
          onBannerLoaded: () {
            _isBannerVisible = true;
            notifyListeners();
          },
          onBannerFailed: (error, message) {
            debugPrint('Unity Banner failed: $error - $message');
          },
          onBannerClick: () {
            debugPrint('Unity Banner clicked');
            // Reward points or other logic here
          },
        ),
      );
    }
  }

  void hideBanner() {
    if (_isBannerVisible) {
      UnityAds.hideBanner();
      _isBannerVisible = false;
      notifyListeners();
    }
  }
}
