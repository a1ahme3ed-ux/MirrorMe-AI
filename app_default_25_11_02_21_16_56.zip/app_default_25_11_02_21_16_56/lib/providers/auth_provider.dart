import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../models/user_model.dart';
import '../services/firebase_service.dart';

class AuthProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  UserModel? _userModel;

  UserModel? get user => _userModel;

  AuthProvider() {
    _auth.authStateChanges().listen(_onAuthStateChanged);
  }

  Future<void> _onAuthStateChanged(User? firebaseUser) async {
    if (firebaseUser == null) {
      _userModel = null;
      notifyListeners();
    } else {
      // Fetch user data from Firestore or create if not exist
      final userDoc = await FirebaseService.usersCollection.doc(firebaseUser.uid).get();
      if (userDoc.exists) {
        _userModel = UserModel.fromDocument(userDoc);
      } else {
        // Create new user doc
        final newUser = UserModel(
          uid: firebaseUser.uid,
          email: firebaseUser.email ?? '',
          displayName: firebaseUser.displayName ?? '',
          photoUrl: firebaseUser.photoURL ?? '',
          points: 0,
          preferredLanguage: 'en',
          darkModeEnabled: false,
        );
        await FirebaseService.usersCollection.doc(firebaseUser.uid).set(newUser.toMap());
        _userModel = newUser;
      }
      notifyListeners();
    }
  }

  Future<bool> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) {
        return false; // User cancelled
      }
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      await _auth.signInWithCredential(credential);
      return true;
    } catch (e) {
      debugPrint('Google sign-in failed: $e');
      return false;
    }
  }

  Future<bool> signUpWithEmail(String email, String password, String displayName) async {
    try {
      final UserCredential cred = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      final user = cred.user;
      if (user != null) {
        await user.updateDisplayName(displayName);
        final newUser = UserModel(
          uid: user.uid,
          email: user.email ?? '',
          displayName: displayName,
          photoUrl: '',
          points: 0,
          preferredLanguage: 'en',
          darkModeEnabled: false,
        );
        await FirebaseService.usersCollection.doc(user.uid).set(newUser.toMap());
        return true;
      }
      return false;
    } on FirebaseAuthException catch (e) {
      debugPrint('Email signup error: ${e.message}');
      return false;
    }
  }

  Future<bool> signInWithEmail(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return true;
    } on FirebaseAuthException catch (e) {
      debugPrint('Email signin error: ${e.message}');
      return false;
    }
  }

  Future<void> logout() async {
    try {
      await _auth.signOut();
      await GoogleSignIn().signOut();
      _userModel = null;
      notifyListeners();
    } catch (e) {
      debugPrint('Logout error: $e');
    }
  }

  Future<void> updateUser(UserModel updatedUser) async {
    try {
      await FirebaseService.usersCollection.doc(updatedUser.uid).update(updatedUser.toMap());
      _userModel = updatedUser;
      notifyListeners();
    } catch (e) {
      debugPrint('Update user error: $e');
    }
  }
}
