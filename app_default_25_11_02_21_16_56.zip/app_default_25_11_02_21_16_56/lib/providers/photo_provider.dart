import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/photo_model.dart';
import '../services/firebase_service.dart';
import '../services/ai_analysis_service.dart';

class PhotoProvider extends ChangeNotifier {
  final List<PhotoModel> _photos = [];
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;

  List<PhotoModel> get photos => List.unmodifiable(_photos);

  bool get isLoading => _isLoading;

  Future<XFile?> pickImageFromGallery() async {
    try {
      final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
      return image;
    } catch (e) {
      debugPrint('Pick image from gallery error: $e');
      return null;
    }
  }

  Future<XFile?> captureImageFromCamera() async {
    try {
      final XFile? image = await _picker.pickImage(source: ImageSource.camera);
      return image;
    } catch (e) {
      debugPrint('Capture image from camera error: $e');
      return null;
    }
  }

  Future<bool> uploadAndAnalyzePhoto({
    required String userId,
    required XFile imageFile,
    required int ageIncrement,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      // Upload image to Firebase Storage
      final storageUrl = await FirebaseService.uploadUserPhoto(userId, imageFile);

      // Call AI analysis service
      final analysisData = await AIAnalysisService.analyzePhoto(imageFile, ageIncrement);

      // Create PhotoModel and save to Firestore
      final photoDoc = await FirebaseService.photosCollection.add({
        'userId': userId,
        'storageUrl': storageUrl,
        'analysisData': analysisData['analysisData'] ?? {},
        'ageIncrement': ageIncrement,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Fetch the created document to map correctly
      final createdDoc = await photoDoc.get();

      final photoModel = PhotoModel.fromDocument(createdDoc);
      _photos.insert(0, photoModel);

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Upload and analyze photo error: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> loadUserPhotos(String userId) async {
    try {
      final querySnapshot = await FirebaseService.photosCollection
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      _photos.clear();
      for (var doc in querySnapshot.docs) {
        _photos.add(PhotoModel.fromDocument(doc));
      }
      notifyListeners();
    } catch (e) {
      debugPrint('Load user photos error: $e');
    }
  }
}
