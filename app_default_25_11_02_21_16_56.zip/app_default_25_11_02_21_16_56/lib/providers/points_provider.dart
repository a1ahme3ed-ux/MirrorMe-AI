import 'package:flutter/material.dart';

import '../models/user_model.dart';
import '../services/firebase_service.dart';

class PointsProvider extends ChangeNotifier {
  int _points = 0;
  String? _userId;

  int get points => _points;

  void setUserId(String userId) {
    _userId = userId;
    _loadPoints();
  }

  Future<void> _loadPoints() async {
    if (_userId == null) return;
    try {
      final doc = await FirebaseService.usersCollection.doc(_userId).get();
      if (doc.exists) {
        final data = doc.data();
        if (data != null && data['points'] is int) {
          _points = data['points'] as int;
        } else {
          _points = 0;
        }
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Load points error: $e');
    }
  }

  Future<void> addPoints(int value) async {
    if (_userId == null) return;
    _points += value;
    notifyListeners();
    try {
      await FirebaseService.usersCollection.doc(_userId).update({'points': _points});
    } catch (e) {
      debugPrint('Update points error: $e');
    }
  }
}
