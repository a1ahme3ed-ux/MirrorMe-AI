import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/constants.dart';

class LanguageProvider extends ChangeNotifier {
  Locale _locale = Constants.supportedLocales.first;

  Locale get locale => _locale;

  LanguageProvider() {
    _loadLocale();
  }

  Future<void> _loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final langCode = prefs.getString(Constants.prefKeyLanguage);
    if (langCode != null && Constants.supportedLocales.any((e) => e.languageCode == langCode)) {
      _locale = Locale(langCode);
      notifyListeners();
    }
  }

  Future<void> toggleLocale() async {
    if (_locale.languageCode == 'en') {
      _locale = const Locale('ar');
    } else {
      _locale = const Locale('en');
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(Constants.prefKeyLanguage, _locale.languageCode);
    notifyListeners();
  }
}
