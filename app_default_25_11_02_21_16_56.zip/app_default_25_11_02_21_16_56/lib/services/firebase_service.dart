import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';

import '../utils/constants.dart';

class FirebaseService {
  static final FirebaseFirestore firestore = FirebaseFirestore.instance;
  static final FirebaseStorage storage = FirebaseStorage.instance;

  static CollectionReference get usersCollection =>
      firestore.collection(Constants.usersCollection);
  static CollectionReference get photosCollection =>
      firestore.collection(Constants.photosCollection);
  static CollectionReference get recommendationsCollection =>
      firestore.collection(Constants.recommendationsCollection);

  static Future<String> uploadUserPhoto(String userId, XFile imageFile) async {
    try {
      final ref = storage.ref().child('user_photos/$userId/${DateTime.now().millisecondsSinceEpoch}_${imageFile.name}');
      final uploadTask = await ref.putFile(File(imageFile.path));
      final downloadUrl = await uploadTask.ref.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      throw Exception('Failed to upload photo: $e');
    }
  }
}
