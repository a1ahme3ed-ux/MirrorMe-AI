import 'package:flutter_unity_ads/flutter_unity_ads.dart';

import '../utils/constants.dart';

class UnityAdsService {
  static Future<void> initialize() async {
    await UnityAds.init(
      gameId: Constants.unityGameId,
      testMode: false,
      onComplete: () {},
      onFailed: (error, message) {},
    );
  }

  static void showBanner() {
    UnityAds.showBanner(
      placementId: Constants.unityBannerAdUnitId,
      listener: UnityBannerAdListener(
        onBannerLoaded: () {},
        onBannerFailed: (error, message) {},
        onBannerClick: () {},
      ),
    );
  }

  static void hideBanner() {
    UnityAds.hideBanner();
  }
}
