import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/recommendation_model.dart';
import '../models/user_model.dart';
import '../utils/constants.dart';

class HealthRecommendationService {
  static Future<List<RecommendationModel>> fetchRecommendations(
      Map<String, dynamic> analysisData, UserModel user) async {
    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection(Constants.recommendationsCollection)
          .where('category', whereIn: ['health', 'beauty'])
          .get();

      final allRecs = querySnapshot.docs
          .map((doc) => RecommendationModel.fromDocument(doc))
          .toList();

      // Filter logic could be added here based on analysisData and user profile
      return allRecs;
    } catch (e) {
      throw Exception('Failed to fetch recommendations: $e');
    }
  }
}
