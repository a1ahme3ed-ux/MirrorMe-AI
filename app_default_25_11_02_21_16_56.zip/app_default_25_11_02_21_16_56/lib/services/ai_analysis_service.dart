import 'dart:io';

class AIAnalysisService {
  // Simulated AI analysis function
  // imageFile: the original photo file
  // ageIncrement: +10 or +20 years
  // Returns a map containing analysis data and future image URL
  static Future<Map<String, dynamic>> analyzePhoto(File imageFile, int ageIncrement) async {
    await Future.delayed(const Duration(seconds: 3)); // simulate delay

    // In a real app, you would call an external AI API here with imageFile and ageIncrement

    // For demonstration, return dummy data
    return {
      'analysisData': {
        'faceChanges': {
          'wrinkles': ageIncrement == 10 ? 'moderate' : 'severe',
          'skinTone': 'duller',
          'hairColor': 'gray',
        },
        'bodyChanges': {
          'posture': 'slightly stooped',
          'muscleTone': 'reduced',
        },
        'points': ageIncrement * 5,
      },
      'futureImageUrl': 'https://picsum.photos/seed/${ageIncrement}future/400/600',
    };
  }
}
