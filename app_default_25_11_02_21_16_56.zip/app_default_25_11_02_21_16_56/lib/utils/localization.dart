import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AppLocalizations {
  static AppLocalizations of(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    if (localizations == null) {
      throw Exception("AppLocalizations not found in context");
    }
    return localizations;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = AppLocalizations.delegate;
}
