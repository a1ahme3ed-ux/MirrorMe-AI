import 'package:flutter/material.dart';

class Constants {
  // Firebase collection names
  static const String usersCollection = "users";
  static const String photosCollection = "photos";
  static const String recommendationsCollection = "recommendations";

  // Unity Ads
  static const String unityGameId = "5975707";
  static const String unityBannerAdUnitId = "Banner_Android"; // Change accordingly
  static const String unityRewardedAdUnitId = "Rewarded_Android"; // Change accordingly

  // Supported locales
  static const List<Locale> supportedLocales = [
    Locale('en'),
    Locale('ar'),
  ];

  // Gradient Colors
  static const Color gradientStart = Color(0xFFB3E5FC); // Light Blue
  static const Color gradientMiddle = Color(0xFF9575CD); // Purple
  static const Color gradientEnd = Color(0xFFFFFFFF); // White

  // Shared Preferences keys
  static const String prefKeyLanguage = "preferredLanguage";
  static const String prefKeyDarkMode = "darkModeEnabled";
}
