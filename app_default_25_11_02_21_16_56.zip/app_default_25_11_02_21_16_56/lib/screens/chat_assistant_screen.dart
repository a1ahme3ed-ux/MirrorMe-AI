import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../utils/localization.dart';

class ChatAssistantScreen extends StatefulWidget {
  static const routeName = '/chat_assistant';

  const ChatAssistantScreen({Key? key}) : super(key: key);

  @override
  State<ChatAssistantScreen> createState() => _ChatAssistantScreenState();
}

class _ChatAssistantScreenState extends State<ChatAssistantScreen> {
  final TextEditingController _inputController = TextEditingController();
  final List<_ChatMessage> _messages = [];
  bool _isLoading = false;

  Future<void> _sendQuery() async {
    final query = _inputController.text.trim();
    if (query.isEmpty) return;

    setState(() {
      _messages.add(_ChatMessage(query, isUser: true));
      _isLoading = true;
    });
    _inputController.clear();

    try {
      final response = await _fakeAIResponse(query);
      setState(() {
        _messages.add(_ChatMessage(response, isUser: false));
        _isLoading = false;
      });
    } catch (_) {
      setState(() {
        _messages.add(_ChatMessage(AppLocalizations.of(context).aiResponseError, isUser: false));
        _isLoading = false;
      });
    }
  }

  Future<String> _fakeAIResponse(String query) async {
    // Placeholder for real AI integration
    await Future.delayed(const Duration(seconds: 2));
    return 'This is a simulated response for: "$query"';
  }

  @override
  void dispose() {
    _inputController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.chatAssistant),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[_messages.length - 1 - index];
                return Align(
                  alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: message.isUser
                          ? Theme.of(context).colorScheme.primaryContainer
                          : Theme.of(context).colorScheme.surfaceVariant,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(message.text),
                  ),
                );
              },
            ),
          ),
          if (_isLoading)
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: CircularProgressIndicator(),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _inputController,
                    decoration: InputDecoration(
                      hintText: l10n.enterQuery,
                      border: const OutlineInputBorder(),
                    ),
                    enabled: !_isLoading,
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _isLoading ? null : _sendQuery,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ChatMessage {
  final String text;
  final bool isUser;

  _ChatMessage(this.text, {required this.isUser});
}
