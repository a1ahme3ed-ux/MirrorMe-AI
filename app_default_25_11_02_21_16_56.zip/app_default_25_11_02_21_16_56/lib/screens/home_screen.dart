import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../providers/photo_provider.dart';
import '../providers/points_provider.dart';
import '../providers/language_provider.dart';
import '../providers/theme_provider.dart';
import '../providers/ads_provider.dart';

import '../widgets/language_toggle.dart';
import '../widgets/dark_mode_toggle.dart';
import '../widgets/points_display.dart';
import '../widgets/photo_capture_widget.dart';
import '../widgets/unity_banner_ad.dart';

import '../utils/localization.dart';

import 'daily_tracking_screen.dart';
import 'chat_assistant_screen.dart';

class HomeScreen extends StatefulWidget {
  static const routeName = '/home';

  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late AuthProvider _authProvider;
  late PhotoProvider _photoProvider;
  late PointsProvider _pointsProvider;
  late LanguageProvider _languageProvider;
  late ThemeProvider _themeProvider;
  late AdsProvider _adsProvider;

  @override
  void initState() {
    super.initState();
    _authProvider = Provider.of<AuthProvider>(context, listen: false);
    _photoProvider = Provider.of<PhotoProvider>(context, listen: false);
    _pointsProvider = Provider.of<PointsProvider>(context, listen: false);
    _languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    _themeProvider = Provider.of<ThemeProvider>(context, listen: false);
    _adsProvider = Provider.of<AdsProvider>(context, listen: false);

    if (_authProvider.user != null) {
      _photoProvider.loadUserPhotos(_authProvider.user!.uid);
      _pointsProvider.setUserId(_authProvider.user!.uid);
    }
    _adsProvider.showBanner();
  }

  @override
  void dispose() {
    _adsProvider.hideBanner();
    super.dispose();
  }

  void _onPhotoPicked(XFile? image) {
    if (image == null) return;

    Navigator.of(context).pushNamed('/photo_analysis', arguments: {
      'imageFile': image,
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final user = _authProvider.user;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.home),
        actions: [
          LanguageToggle(),
          DarkModeToggle(),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: user == null
            ? Center(child: Text(l10n.errorSignInFailed))
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${l10n.home}, ${user.displayName}',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  PointsDisplay(),
                  const SizedBox(height: 16),
                  PhotoCaptureWidget(onImagePicked: _onPhotoPicked),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.timeline),
                    label: Text(l10n.dailyProgress),
                    onPressed: () {
                      Navigator.of(context).pushNamed(DailyTrackingScreen.routeName);
                    },
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.chat),
                    label: Text(l10n.chatAssistant),
                    onPressed: () {
                      Navigator.of(context).pushNamed(ChatAssistantScreen.routeName);
                    },
                  ),
                ],
              ),
      ),
      bottomNavigationBar: const UnityBannerAd(),
    );
  }
}
