import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/photo_model.dart';
import '../providers/auth_provider.dart';
import '../providers/photo_provider.dart';
import '../services/health_recommendation_service.dart';
import '../models/recommendation_model.dart';
import '../utils/localization.dart';

class PhotoAnalysisScreen extends StatefulWidget {
  static const routeName = '/photo_analysis';

  const PhotoAnalysisScreen({Key? key}) : super(key: key);

  @override
  State<PhotoAnalysisScreen> createState() => _PhotoAnalysisScreenState();
}

class _PhotoAnalysisScreenState extends State<PhotoAnalysisScreen> {
  late File _imageFile;
  int? _selectedAgeIncrement;
  PhotoModel? _photoModel;
  List<RecommendationModel> _healthRecommendations = [];
  List<RecommendationModel> _beautyRecommendations = [];
  bool _isLoading = false;
  bool _hasAnalysis = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null && args['imageFile'] != null) {
      final dynamic file = args['imageFile'];
      if (file is File) {
        _imageFile = file;
      } else if (file is XFile) {
        _imageFile = File(file.path);
      } else {
        throw Exception('Invalid imageFile argument');
      }
    } else {
      Navigator.of(context).pop();
    }
  }

  Future<void> _analyzePhoto(int ageIncrement) async {
    setState(() {
      _isLoading = true;
      _selectedAgeIncrement = ageIncrement;
    });

    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final photoProvider = Provider.of<PhotoProvider>(context, listen: false);

    if (authProvider.user == null) {
      setState(() {
        _isLoading = false;
      });
      return;
    }

    final success = await photoProvider.uploadAndAnalyzePhoto(
      userId: authProvider.user!.uid,
      imageFile: XFile(_imageFile.path),
      ageIncrement: ageIncrement,
    );

    if (!success) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppLocalizations.of(context).errorSignInFailed)),
      );
      return;
    }

    final photos = photoProvider.photos;
    if (photos.isNotEmpty) {
      _photoModel = photos.first;
      final recs = await HealthRecommendationService.fetchRecommendations(
        _photoModel!.analysisData,
        authProvider.user!,
      );
      _healthRecommendations = recs.where((r) => r.category == 'health').toList();
      _beautyRecommendations = recs.where((r) => r.category == 'beauty').toList();
      setState(() {
        _hasAnalysis = true;
        _isLoading = false;
      });
    }
  }

  void _shareImage() {
    if (_photoModel == null) return;
    Share.shareFiles([_photoModel!.storageUrl], text: AppLocalizations.of(context).share);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.photoAnalysis),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Image.file(_imageFile),
                  const SizedBox(height: 16),
                  Text(
                    l10n.selectAgeIncrement,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: _selectedAgeIncrement == 10 ? null : () => _analyzePhoto(10),
                        child: Text(l10n.agePlus10),
                      ),
                      const SizedBox(width: 16),
                      ElevatedButton(
                        onPressed: _selectedAgeIncrement == 20 ? null : () => _analyzePhoto(20),
                        child: Text(l10n.agePlus20),
                      ),
                    ],
                  ),
                  if (_hasAnalysis && _photoModel != null) ...[
                    const SizedBox(height: 24),
                    Image.network(
                      _photoModel!.storageUrl,
                      height: 300,
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) => const Icon(Icons.broken_image, size: 100),
                    ),
                    const SizedBox(height: 24),
                    Text(l10n.healthRecommendations, style: Theme.of(context).textTheme.titleLarge),
                    ..._healthRecommendations.map((rec) => ListTile(title: Text(rec.text))).toList(),
                    const SizedBox(height: 16),
                    Text(l10n.beautyRecommendations, style: Theme.of(context).textTheme.titleLarge),
                    ..._beautyRecommendations.map((rec) => ListTile(title: Text(rec.text))).toList(),
                    const SizedBox(height: 24),
                    ElevatedButton.icon(
                      icon: const Icon(Icons.share),
                      label: Text(l10n.share),
                      onPressed: _shareImage,
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}
