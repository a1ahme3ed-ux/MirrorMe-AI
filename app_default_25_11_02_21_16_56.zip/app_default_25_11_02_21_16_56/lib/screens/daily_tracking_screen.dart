import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../providers/photo_provider.dart';
import '../models/photo_model.dart';
import '../utils/localization.dart';

class DailyTrackingScreen extends StatefulWidget {
  static const routeName = '/daily_tracking';

  const DailyTrackingScreen({Key? key}) : super(key: key);

  @override
  State<DailyTrackingScreen> createState() => _DailyTrackingScreenState();
}

class _DailyTrackingScreenState extends State<DailyTrackingScreen> {
  final Set<String> _selectedPhotoIds = {};

  @override
  void initState() {
    super.initState();
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final photoProvider = Provider.of<PhotoProvider>(context, listen: false);
    if (authProvider.user != null) {
      photoProvider.loadUserPhotos(authProvider.user!.uid);
    }
  }

  void _onPhotoTap(PhotoModel photo) {
    setState(() {
      if (_selectedPhotoIds.contains(photo.photoId)) {
        _selectedPhotoIds.remove(photo.photoId);
      } else {
        if (_selectedPhotoIds.length < 2) {
          _selectedPhotoIds.add(photo.photoId);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final photoProvider = Provider.of<PhotoProvider>(context);
    final photos = photoProvider.photos;

    final selectedPhotos = photos.where((p) => _selectedPhotoIds.contains(p.photoId)).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.dailyProgress),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          final authProvider = Provider.of<AuthProvider>(context, listen: false);
          if (authProvider.user != null) {
            await photoProvider.loadUserPhotos(authProvider.user!.uid);
          }
        },
        child: photos.isEmpty
            ? Center(child: Text(l10n.pullToRefresh))
            : ListView.builder(
                itemCount: photos.length,
                itemBuilder: (context, index) {
                  final photo = photos[index];
                  final isSelected = _selectedPhotoIds.contains(photo.photoId);
                  return ListTile(
                    leading: Image.network(
                      photo.storageUrl,
                      width: 60,
                      height: 60,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          const Icon(Icons.broken_image),
                    ),
                    title: Text('Age +${photo.ageIncrement}'),
                    subtitle: Text(
                      '${l10n.improvementPoints}: ${(photo.analysisData['points'] ?? 0).toString()}',
                    ),
                    trailing: isSelected ? const Icon(Icons.check_circle) : null,
                    selected: isSelected,
                    onTap: () => _onPhotoTap(photo),
                  );
                },
              ),
      ),
      bottomNavigationBar: selectedPhotos.length == 2
          ? Container(
              padding: const EdgeInsets.all(8),
              height: 220,
              color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: selectedPhotos.map((photo) {
                  return Image.network(
                    photo.storageUrl,
                    width: 150,
                    height: 200,
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.broken_image, size: 100),
                  );
                }).toList(),
              ),
            )
          : null,
    );
  }
}
