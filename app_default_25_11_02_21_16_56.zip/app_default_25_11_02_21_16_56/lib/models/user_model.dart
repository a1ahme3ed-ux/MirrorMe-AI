import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String email;
  final String displayName;
  final String photoUrl;
  final int points;
  final String preferredLanguage; // 'en' or 'ar'
  final bool darkModeEnabled;

  UserModel({
    required this.uid,
    required this.email,
    required this.displayName,
    required this.photoUrl,
    required this.points,
    required this.preferredLanguage,
    required this.darkModeEnabled,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] as String? ?? '',
      email: map['email'] as String? ?? '',
      displayName: map['displayName'] as String? ?? '',
      photoUrl: map['photoUrl'] as String? ?? '',
      points: map['points'] as int? ?? 0,
      preferredLanguage: map['preferredLanguage'] as String? ?? 'en',
      darkModeEnabled: map['darkModeEnabled'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'points': points,
      'preferredLanguage': preferredLanguage,
      'darkModeEnabled': darkModeEnabled,
    };
  }

  factory UserModel.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return UserModel.fromMap({...data, 'uid': doc.id});
  }
}
