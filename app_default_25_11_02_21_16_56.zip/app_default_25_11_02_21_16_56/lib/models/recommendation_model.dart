import 'package:cloud_firestore/cloud_firestore.dart';

class RecommendationModel {
  final String recId;
  final String userId;
  final String text;
  final String category; // "health" or "beauty"
  final Timestamp createdAt;

  RecommendationModel({
    required this.recId,
    required this.userId,
    required this.text,
    required this.category,
    required this.createdAt,
  });

  factory RecommendationModel.fromMap(Map<String, dynamic> map) {
    return RecommendationModel(
      recId: map['recId'] as String? ?? '',
      userId: map['userId'] as String? ?? '',
      text: map['text'] as String? ?? '',
      category: map['category'] as String? ?? 'health',
      createdAt: map['createdAt'] as Timestamp? ?? Timestamp.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'recId': recId,
      'userId': userId,
      'text': text,
      'category': category,
      'createdAt': createdAt,
    };
  }

  factory RecommendationModel.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return RecommendationModel.fromMap({...data, 'recId': doc.id});
  }
}
