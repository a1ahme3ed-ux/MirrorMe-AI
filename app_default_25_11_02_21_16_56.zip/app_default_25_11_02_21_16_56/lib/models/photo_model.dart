import 'package:cloud_firestore/cloud_firestore.dart';

class PhotoModel {
  final String photoId;
  final String userId;
  final String storageUrl;
  final Map<String, dynamic> analysisData;
  final int ageIncrement; // +10 or +20
  final Timestamp createdAt;

  PhotoModel({
    required this.photoId,
    required this.userId,
    required this.storageUrl,
    required this.analysisData,
    required this.ageIncrement,
    required this.createdAt,
  });

  factory PhotoModel.fromMap(Map<String, dynamic> map) {
    return PhotoModel(
      photoId: map['photoId'] as String? ?? '',
      userId: map['userId'] as String? ?? '',
      storageUrl: map['storageUrl'] as String? ?? '',
      analysisData: Map<String, dynamic>.from(map['analysisData'] ?? {}),
      ageIncrement: map['ageIncrement'] as int? ?? 10,
      createdAt: map['createdAt'] as Timestamp? ?? Timestamp.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'photoId': photoId,
      'userId': userId,
      'storageUrl': storageUrl,
      'analysisData': analysisData,
      'ageIncrement': ageIncrement,
      'createdAt': createdAt,
    };
  }

  factory PhotoModel.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return PhotoModel.fromMap({...data, 'photoId': doc.id});
  }
}
