import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'screens/splash_screen.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/chat_assistant_screen.dart';
import 'screens/photo_analysis_screen.dart';
import 'screens/daily_tracking_screen.dart';

import 'utils/constants.dart';
import 'utils/theme.dart';
import 'utils/localization.dart';
import 'providers/language_provider.dart';
import 'providers/theme_provider.dart';

class MirrorMeApp extends StatefulWidget {
  const MirrorMeApp({Key? key}) : super(key: key);

  @override
  State<MirrorMeApp> createState() => _MirrorMeAppState();
}

class _MirrorMeAppState extends State<MirrorMeApp> {
  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final themeProvider = Provider.of<ThemeProvider>(context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MirrorMe AI',
      theme: themeProvider.lightTheme,
      darkTheme: themeProvider.darkTheme,
      themeMode: themeProvider.isDarkMode ? ThemeMode.dark : ThemeMode.light,
      locale: languageProvider.locale,
      supportedLocales: Constants.supportedLocales,
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      localeResolutionCallback: (locale, supportedLocales) {
        if (locale == null) return supportedLocales.first;
        for (var supportedLocale in supportedLocales) {
          if (supportedLocale.languageCode == locale.languageCode) {
            return supportedLocale;
          }
        }
        return supportedLocales.first;
      },
      initialRoute: SplashScreen.routeName,
      routes: {
        SplashScreen.routeName: (_) => const SplashScreen(),
        AuthScreen.routeName: (_) => const AuthScreen(),
        HomeScreen.routeName: (_) => const HomeScreen(),
        SettingsScreen.routeName: (_) => const SettingsScreen(),
        ChatAssistantScreen.routeName: (_) => const ChatAssistantScreen(),
        PhotoAnalysisScreen.routeName: (_) => const PhotoAnalysisScreen(),
        DailyTrackingScreen.routeName: (_) => const DailyTrackingScreen(),
      },
      navigatorObservers: const [],
      builder: (context, child) {
        // Gradient background scaffold wrapping all screens
        return Container(
          decoration: BoxDecoration(
            gradient: themeProvider.isDarkMode
                ? AppTheme.darkGradient
                : AppTheme.lightGradient,
          ),
          child: child,
        );
      },
    );
  }
}
