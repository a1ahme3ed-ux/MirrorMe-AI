import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'package:flutter_unity_ads/flutter_unity_ads.dart';

import 'app.dart';
import 'providers/auth_provider.dart';
import 'providers/photo_provider.dart';
import 'providers/language_provider.dart';
import 'providers/theme_provider.dart';
import 'providers/points_provider.dart';
import 'providers/ads_provider.dart';
import 'utils/constants.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    // Firebase initialization error handling
    debugPrint('Firebase initialization error: $e');
  }

  try {
    UnityAds.init(
      gameId: Constants.unityGameId,
      testMode: false,
      onComplete: () {
        debugPrint('Unity Ads initialization complete');
      },
      onFailed: (error, message) {
        debugPrint('Unity Ads initialization failed: $error - $message');
      },
    );
  } catch (e) {
    debugPrint('Unity Ads init error: $e');
  }

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => AuthProvider()),
      ChangeNotifierProvider(create: (_) => PhotoProvider()),
      ChangeNotifierProvider(create: (_) => LanguageProvider()),
      ChangeNotifierProvider(create: (_) => ThemeProvider()),
      ChangeNotifierProvider(create: (_) => PointsProvider()),
      ChangeNotifierProvider(create: (_) => AdsProvider()),
    ],
    child: const MirrorMeApp(),
  ));
}
