import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

class PhotoCaptureWidget extends StatefulWidget {
  final void Function(XFile?) onImagePicked;

  const PhotoCaptureWidget({Key? key, required this.onImagePicked}) : super(key: key);

  @override
  State<PhotoCaptureWidget> createState() => _PhotoCaptureWidgetState();
}

class _PhotoCaptureWidgetState extends State<PhotoCaptureWidget> {
  final ImagePicker _picker = ImagePicker();
  bool _isPicking = false;

  Future<void> _pickFromGallery() async {
    setState(() {
      _isPicking = true;
    });
    final status = await Permission.photos.request();
    if (!status.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Permission to access gallery denied')),
      );
      setState(() {
        _isPicking = false;
      });
      return;
    }
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    widget.onImagePicked(image);
    setState(() {
      _isPicking = false;
    });
  }

  Future<void> _captureFromCamera() async {
    setState(() {
      _isPicking = true;
    });
    final status = await Permission.camera.request();
    if (!status.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Permission to access camera denied')),
      );
      setState(() {
        _isPicking = false;
      });
      return;
    }
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);
    widget.onImagePicked(image);
    setState(() {
      _isPicking = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ElevatedButton.icon(
          icon: const Icon(Icons.photo_library),
          label: const Text('Upload Photo'),
          onPressed: _isPicking ? null : _pickFromGallery,
          style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
        ),
        const SizedBox(height: 12),
        ElevatedButton.icon(
          icon: const Icon(Icons.camera_alt),
          label: const Text('Capture Photo'),
          onPressed: _isPicking ? null : _captureFromCamera,
          style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
        ),
      ],
    );
  }
}
