import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/points_provider.dart';
import '../utils/localization.dart';

class PointsDisplay extends StatelessWidget {
  const PointsDisplay({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final pointsProvider = Provider.of<PointsProvider>(context);
    final l10n = AppLocalizations.of(context);

    return Row(
      children: [
        const Icon(Icons.star, color: Colors.amber),
        const SizedBox(width: 8),
        Text(
          '${l10n.points}: ${pointsProvider.points}',
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ],
    );
  }
}
