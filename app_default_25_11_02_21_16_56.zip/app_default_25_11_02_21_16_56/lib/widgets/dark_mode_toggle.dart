import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/theme_provider.dart';

class DarkModeToggle extends StatelessWidget {
  const DarkModeToggle({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Switch(
      value: themeProvider.isDarkMode,
      onChanged: (_) {
        themeProvider.toggleTheme();
      },
      activeColor: Theme.of(context).colorScheme.primary,
      inactiveThumbColor: Colors.grey,
    );
  }
}
