import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/language_provider.dart';

class LanguageToggle extends StatelessWidget {
  const LanguageToggle({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isEnglish = languageProvider.locale.languageCode == 'en';

    return IconButton(
      tooltip: 'Toggle Language',
      icon: Text(
        isEnglish ? 'EN' : 'AR',
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
      ),
      onPressed: () {
        languageProvider.toggleLocale();
      },
    );
  }
}
