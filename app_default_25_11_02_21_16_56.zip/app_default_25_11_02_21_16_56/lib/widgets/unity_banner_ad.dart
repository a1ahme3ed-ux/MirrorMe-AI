import 'package:flutter/material.dart';
import 'package:flutter_unity_ads/flutter_unity_ads.dart';
import 'package:provider/provider.dart';

import '../providers/ads_provider.dart';
import '../utils/constants.dart';

class UnityBannerAd extends StatefulWidget {
  const UnityBannerAd({Key? key}) : super(key: key);

  @override
  State<UnityBannerAd> createState() => _UnityBannerAdState();
}

class _UnityBannerAdState extends State<UnityBannerAd> {
  @override
  void initState() {
    super.initState();
    final adsProvider = Provider.of<AdsProvider>(context, listen: false);
    adsProvider.showBanner();
  }

  @override
  void dispose() {
    final adsProvider = Provider.of<AdsProvider>(context, listen: false);
    adsProvider.hideBanner();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: UnityBannerAdWidget(
        placementId: Constants.unityBannerAdUnitId,
        listener: (state, args) {
          final adsProvider = Provider.of<AdsProvider>(context, listen: false);
          if (state == UnityBannerAdState.loaded) {
            adsProvider.showBanner();
          } else if (state == UnityBannerAdState.failed) {
            adsProvider.hideBanner();
          }
        },
      ),
    );
  }
}
